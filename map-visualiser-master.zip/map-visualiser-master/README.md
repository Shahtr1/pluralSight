# map-visualiser
Visualises the internal data structures of different Java Map implementations
